import { defineCard } from '@/app/(protected)/(cards)/utils/defineCard'

export default defineCard({
  id: 'brand-of-the-comet',
  type: 'attachment',
  subtype: 'curse',
  name: 'Brand of the Comet',
  text: "Attach to an enemy ally: it can't use its ability and has -1 attack.",
  faction: 'void',
  restriction: { factions: ['void'] },
  rarity: 'uncommon',
  price: 160,
  cost: 3,
  attack: -1,
  targets: ['enemyAlly'],
  silences: true,
  ai: { value: 3, tags: ['removal'] },
  art: {
    subject:
      'Brand of the Comet: an enchanted brand made of rusted iron and chains, on a pile of old coins, dramatic backlight, rose pink accents, mage style'
  }
})

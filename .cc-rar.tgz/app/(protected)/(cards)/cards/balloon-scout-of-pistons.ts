import { defineCard } from '@/app/(protected)/(cards)/utils/defineCard'
import { buff, damage, isTribe } from '@/app/(protected)/(engine)/effects'

export default defineCard({
  id: 'balloon-scout-of-pistons',
  type: 'ally',
  name: 'Balloon Scout of Pistons',
  text: 'When another Skyship of yours enters: it gains +1 attack and +1 health. Its ability is paid with energy (⚡).',
  faction: 'clockwork',
  restriction: { factions: ['clockwork'] },
  rarity: 'uncommon',
  weak: ['wind'],
  price: 160,
  cost: 3,
  tribe: 'skyship',
  keywords: ['shield'],
  attack: 4,
  health: 4,
  ability: {
    name: 'Strike',
    text: 'Deal 5 damage to an enemy slot.',
    cost: 2,
    resource: 'energy',
    targets: ['enemySlot'],
    activate(ctx) {
      damage(ctx, ctx.targets[0], 5)
    }
  },
  onAllyEnter(ctx, ally) {
    if (isTribe(ally, 'skyship')) {
      buff(ctx, ally, 1, 1)
    }
  },
  ai: { value: 3, tags: ['ability', 'buff', 'energy', 'tribe'] },
  art: {
    subject:
      'Balloon Scout of Pistons: a scout built of chrome with cyan light strips, with bolted armor plates, marching forward, steampunk steam era style'
  }
})

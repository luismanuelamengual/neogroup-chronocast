import { defineCard } from '@/app/(protected)/(cards)/utils/defineCard'

export default defineCard({
  id: 'frozen-ward',
  type: 'armor',
  subtype: 'robe',
  name: 'Frozen Ward',
  text: '',
  flavor: 'Cold enough to stop a sword mid-swing.',
  faction: 'arcane',
  restriction: { factions: ['arcane'] },
  rarity: 'uncommon',
  price: 120,
  cost: 1,
  armor: 1,
  durability: 3,
  ai: { value: 1 },
  art: {
    subject:
      'Frozen Ward: a single ward made of copper with green patina, stuck in the sand, swirling around the center, magenta accents, mage style'
  }
})

import { defineCard } from '@/app/(protected)/(cards)/utils/defineCard'
import { gainEnergy } from '@/app/(protected)/(engine)/effects'

export default defineCard({
  id: 'altar-of-pistons',
  type: 'artifact',
  name: 'Altar of Pistons',
  text: 'At the start of each phase: your hero gains 1 energy.',
  flavor: 'Offerings of oil to the god of machines.',
  faction: 'clockwork',
  restriction: { factions: ['clockwork'], sides: ['dawn'] },
  rarity: 'epic',
  price: 900,
  cost: 1,
  onPhaseStart(ctx) {
    gainEnergy(ctx, ctx.owner, 1)
  },
  ai: { value: 2, tags: ['energy'] },
  art: {
    subject:
      'Altar of Pistons: an ancient altar made of ivory and jade, standing on a windy cliff, diagonal dynamic composition, saffron yellow accents, steampunk steam era style'
  }
})

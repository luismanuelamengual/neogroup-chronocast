import { defineCard } from '@/app/(protected)/(cards)/utils/defineCard'
import { summonCard } from '@/app/(protected)/(engine)/effects'

export default defineCard({
  id: 'healing-muster',
  type: 'ability',
  subtype: 'tactic',
  name: 'Healing Muster',
  text: 'Summon a Guardian Spirit.',
  flavor: 'Gather the wounded. Send back soldiers.',
  faction: 'bronze',
  restriction: { factions: ['bronze'], sides: ['dawn'] },
  rarity: 'rare',
  price: 360,
  cost: 2,
  onPlay(ctx) {
    summonCard(ctx, ctx.owner, 'guardian-spirit')
  },
  ai: { value: 3, tags: ['summon'] },
  art: {
    subject:
      'Healing Muster: a row of empty helmets and spears lit by dawn light, over a desert of red dunes, seen from above, turquoise accents, mystic healer style'
  }
})

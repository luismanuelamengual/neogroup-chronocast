import { defineCard } from '@/app/(protected)/(cards)/utils/defineCard'
import { healHero } from '@/app/(protected)/(engine)/effects'

export default defineCard({
  id: 'kades-cleaver',
  type: 'weapon',
  subtype: 'energy',
  name: "Kade's Plasma Cleaver",
  text: 'When it is equipped: your hero heals 5.',
  flavor: 'Order, one cut at a time.',
  faction: 'neon',
  restriction: { factions: ['neon'], sides: ['eclipse'] },
  rarity: 'epic',
  price: 1100,
  cost: 3,
  keywords: ['unique'],
  attack: 5,
  durability: 4,
  onPlay(ctx) {
    healHero(ctx, 5)
  },
  ai: { value: 5 },
  art: {
    subject:
      "Kade's Plasma Cleaver: a single heavy cleaver with a glowing plasma edge made of ivory and jade, in a beam of light from above, diagonal dynamic composition, amber accents, neon cyberpunk future style"
  }
})

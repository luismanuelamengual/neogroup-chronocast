import { defineCard } from '@/app/(protected)/(cards)/utils/defineCard'
import { buffThisPhaseAt } from '@/app/(protected)/(engine)/effects'

export default defineCard({
  id: 'might-of-valor',
  type: 'ability',
  subtype: 'tactic',
  name: 'Might of Valor',
  text: 'An ally of yours gains +4 attack this phase. Instant.',
  flavor: 'Brave hearts swing harder.',
  faction: 'bronze',
  restriction: { factions: ['bronze'], sides: ['dawn'] },
  rarity: 'epic',
  price: 900,
  cost: 1,
  speed: 'instant',
  targets: ['friendlyAlly'],
  onPlay(ctx) {
    buffThisPhaseAt(ctx, ctx.targets[0], 4)
  },
  ai: { value: 2, tags: ['buff'] },
  art: {
    subject:
      'Might of Valor: a huge glowing fist-shaped aura of raw power, in a ruined temple, close-up filling the frame, indigo accents, warrior style'
  }
})
